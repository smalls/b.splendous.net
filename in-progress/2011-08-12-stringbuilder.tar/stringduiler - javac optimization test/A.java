public class A {
	public static String test() {
		StringBuilder sb = new StringBuilder();
		return sb.append("a").append(""+System.currentTimeMillis()).append("c").toString();
	}
	public static void main(String[] args) {
		System.out.println("sb: "+test());
	}
};
