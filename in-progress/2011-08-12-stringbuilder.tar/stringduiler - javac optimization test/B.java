public class B {
	public static String test() {
		return "a"+(""+System.currentTimeMillis())+("c");
	}
	public static void main(String[] args) {
		System.out.println("sp: "+test());
	}
};
